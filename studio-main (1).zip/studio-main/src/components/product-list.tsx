
"use client";

import * as React from "react";
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from "@/components/ui/table";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "./ui/card";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { FilePenLine, Trash2, PackagePlus, Upload, Loader2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from "./ui/dialog";
import ProductForm from "./product-form";
import type { Product } from "@/lib/schemas";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "./ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { Label } from "./ui/label";

const ImportModal = ({
    open,
    onOpenChange,
    onImport,
    sampleFileName,
    expectedHeaders
}: {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    onImport: (data: any[]) => void;
    sampleFileName: string;
    expectedHeaders: string[];
}) => {
    const { toast } = useToast();
    const [file, setFile] = React.useState<File | null>(null);
    const [isProcessing, setIsProcessing] = React.useState(false);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            setFile(e.target.files[0]);
        }
    };

    const handleImport = () => {
        if (!file) {
            toast({
                variant: "destructive",
                title: "Nenhum arquivo selecionado",
                description: "Por favor, selecione um arquivo CSV para importar.",
            });
            return;
        }

        setIsProcessing(true);
        const reader = new FileReader();
        reader.onload = (e) => {
            const text = e.target?.result as string;
            const lines = text.split(/\r\n|\n/);
            const headers = lines[0].split(';').map(h => h.trim());
            
            const missingHeaders = expectedHeaders.filter(h => !headers.includes(h));
            if (missingHeaders.length > 0) {
                 toast({
                    variant: "destructive",
                    title: "Cabeçalhos Incorretos",
                    description: `O arquivo não contém as colunas esperadas: ${missingHeaders.join(', ')}.`,
                });
                setIsProcessing(false);
                return;
            }

            const data = [];
            for (let i = 1; i < lines.length; i++) {
                if (!lines[i]) continue;
                const values = lines[i].split(';');
                const row: { [key: string]: any } = {};
                for (let j = 0; j < headers.length; j++) {
                    row[headers[j]] = values[j];
                }
                data.push(row);
            }
            onImport(data);
            setIsProcessing(false);
            onOpenChange(false);
        };
        reader.onerror = () => {
            toast({
                variant: "destructive",
                title: "Erro ao ler arquivo",
                description: "Não foi possível processar o arquivo selecionado.",
            });
            setIsProcessing(false);
        }
        reader.readAsText(file, 'UTF-8');
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Importar Produtos via CSV</DialogTitle>
                    <CardDescription>
                        Baixe o arquivo de exemplo, preencha com seus dados e faça o upload.
                    </CardDescription>
                </DialogHeader>
                <div className="py-4 space-y-4">
                    <a href={`/${sampleFileName}`} download>
                        <Button variant="outline" className="w-full">
                            Baixar Arquivo de Exemplo
                        </Button>
                    </a>
                    <div className="space-y-2">
                        <Label htmlFor="csv-file">Arquivo CSV</Label>
                        <Input id="csv-file" type="file" accept=".csv" onChange={handleFileChange} />
                    </div>
                </div>
                <DialogFooter>
                    <Button onClick={handleImport} disabled={!file || isProcessing}>
                        {isProcessing ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processando...</> : "Processar Importação"}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};


interface ProductListProps {
    products: (Product & { id: string })[];
    onUpdateProduct: (product: Product & { id: string }) => void;
    onDeleteProduct: (productId: string) => void;
    onNewProductClick: () => void;
}


export default function ProductList({ products, onUpdateProduct, onDeleteProduct, onNewProductClick }: ProductListProps) {
  const { toast } = useToast();
  const [nameFilter, setNameFilter] = React.useState("");
  const [filteredProducts, setFilteredProducts] = React.useState(products);
  const [editingProduct, setEditingProduct] = React.useState<(Product & { id: string }) | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = React.useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = React.useState(false);

  React.useEffect(() => {
    const lowercasedNameFilter = nameFilter.toLowerCase();
    const filtered = products.filter((product) => 
      product.name.toLowerCase().includes(lowercasedNameFilter)
    );
    setFilteredProducts(filtered);
  }, [nameFilter, products]);
  
  const handleEditClick = (product: Product & { id: string }) => {
    setEditingProduct(product);
    setIsEditDialogOpen(true);
  }

  const handleDeleteClick = (productId: string) => {
    onDeleteProduct(productId);
    toast({
        title: "Produto Excluído!",
        description: "O produto foi removido com sucesso.",
        variant: "destructive",
      });
  }

  const handleFormSuccess = (updatedProduct: Product & { id: string }) => {
    onUpdateProduct(updatedProduct);
    setIsEditDialogOpen(false);
    setEditingProduct(null);
     toast({
        title: "Sucesso!",
        description: "Produto atualizado com sucesso.",
      });
  };

  const handleImportProducts = (data: any[]) => {
    let importedCount = 0;
    let skippedCount = 0;

    data.forEach(row => {
        const name = row['name'];
        if (!name) {
            skippedCount++;
            return;
        }

        const isDuplicate = products.some(p => p.name.toLowerCase() === name.toLowerCase());
        if (isDuplicate) {
            skippedCount++;
            return;
        }

        const productData: Product & { id: string } = {
            id: `prod-${Date.now()}-${Math.random()}`,
            name: name,
            category: row['category'] || 'OUTROS',
            price: Number(row['price']) || 0,
            rawMaterialCost: Number(row['rawMaterialCost']) || 0,
            laborCost: Number(row['laborCost']) || 0,
            suppliesCost: Number(row['suppliesCost']) || 0,
            fees: Number(row['fees']) || 0,
            taxes: Number(row['taxes']) || 0,
            profitMargin: Number(row['profitMargin']) || 0,
            productionMinutes: Number(row['productionMinutes']) || 0,
        };
        onUpdateProduct(productData); // Using onUpdateProduct to add new product to the list
        importedCount++;
    });

    toast({
        title: "Importação Concluída",
        description: `${importedCount} produtos importados. ${skippedCount} duplicados ou inválidos foram ignorados.`,
    });
};

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <div className="flex justify-between items-center flex-wrap gap-2">
            <div>
              <CardTitle>Produtos Cadastrados</CardTitle>
              <CardDescription>
                Visualize e gerencie os produtos cadastrados no sistema.
              </CardDescription>
            </div>
            <div className="flex gap-2">
                <Button onClick={() => setIsImportModalOpen(true)} variant="outline">
                    <Upload className="mr-2 h-4 w-4" />
                    Importar via CSV
                </Button>
                <Button onClick={onNewProductClick}>
                <PackagePlus className="mr-2 h-4 w-4" />
                Novo Produto
                </Button>
            </div>
        </div>
        <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
            <Input
              placeholder="Filtrar por nome do produto..."
              value={nameFilter}
              onChange={(e) => setNameFilter(e.target.value)}
            />
          </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome do Produto</TableHead>
                <TableHead className="text-right">Preço de Venda</TableHead>
                <TableHead className="text-right w-[120px]">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredProducts.map((product) => (
                <TableRow key={product.id}>
                  <TableCell className="font-medium">{product.name}</TableCell>
                  <TableCell className="text-right">
                    {product.price.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Button variant="outline" size="icon" onClick={() => handleEditClick(product)}>
                          <FilePenLine className="h-4 w-4" />
                          <span className="sr-only">Editar</span>
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="destructive" size="icon">
                              <Trash2 className="h-4 w-4" />
                              <span className="sr-only">Excluir</span>
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Você tem certeza?</AlertDialogTitle>
                              <AlertDialogDescription>
                                Essa ação não pode ser desfeita. Isso excluirá permanentemente o produto.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancelar</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDeleteClick(product.id)}>
                                Excluir
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
          <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
            <DialogContent className="sm:max-w-2xl">
              <DialogHeader>
                <DialogTitle>Editar Produto</DialogTitle>
              </DialogHeader>
              <ProductForm
                initialData={editingProduct}
                onSuccess={handleFormSuccess}
              />
            </DialogContent>
          </Dialog>
           <ImportModal
                open={isImportModalOpen}
                onOpenChange={setIsImportModalOpen}
                onImport={handleImportProducts}
                sampleFileName="produtos-exemplo.csv"
                expectedHeaders={["name", "category", "price", "rawMaterialCost", "laborCost", "suppliesCost", "fees", "taxes", "profitMargin", "productionMinutes"]}
            />
      </CardContent>
    </Card>
  );
}
