
export const firebaseConfig = {
  "projectId": "app-de-vendas-do-rodrigo",
  "appId": "1:914619342731:web:53d0859c258d4a66a7e0a1",
  "apiKey": "AIzaSyAzF-S5xLssFhL66A39vE1CgGfe003fBPI",
  "authDomain": "app-de-vendas-do-rodrigo.firebaseapp.com",
  "measurementId": "",
  "storageBucket": "app-de-vendas-do-rodrigo.appspot.com",
  "messagingSenderId": "914619342731"
};

    